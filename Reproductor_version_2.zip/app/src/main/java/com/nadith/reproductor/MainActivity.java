package com.nadith.reproductor;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;

/** Muestra tu reproductor HTML dentro de una app, sin cambiarle nada. */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final int PEDIR_ARCHIVOS = 1;
    private static final int FONDO = Color.parseColor("#07070d");

    private WebView web;
    private ValueCallback<Uri[]> pendiente;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(FONDO);
        getWindow().setNavigationBarColor(FONDO);

        web = new WebView(this);
        web.setBackgroundColor(FONDO);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !HOST.equals(r.getUrl().getHost());
            }

            // Sirve tu HTML desde la app con una dirección segura (https), para que
            // la biblioteca de canciones se guarde bien en el dispositivo.
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String ruta = u.getPath();
                if (ruta == null || ruta.equals("/") || ruta.isEmpty()) ruta = "/index.html";
                String nombre = ruta.substring(1);
                if (!nombre.contains("..")) {
                    try {
                        InputStream in = getAssets().open(nombre);
                        return new WebResourceResponse(tipo(nombre), "UTF-8", in);
                    } catch (Exception ignorada) {
                    }
                }
                return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                        new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
            }
        });

        // Hace funcionar el botón de agregar música (selector de archivos).
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (pendiente != null) pendiente.onReceiveValue(null);
                pendiente = cb;
                try {
                    startActivityForResult(p.createIntent(), PEDIR_ARCHIVOS);
                } catch (Exception e) {
                    pendiente = null;
                    cb.onReceiveValue(null);
                }
                return true;
            }
        });

        setContentView(web);
        web.loadUrl("https://" + HOST + "/index.html");
    }

    private static String tipo(String nombre) {
        String n = nombre.toLowerCase(Locale.US);
        if (n.endsWith(".html")) return "text/html";
        if (n.endsWith(".js")) return "application/javascript";
        if (n.endsWith(".css")) return "text/css";
        if (n.endsWith(".json")) return "application/json";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".svg")) return "image/svg+xml";
        return "application/octet-stream";
    }

    @Override
    protected void onActivityResult(int codigo, int resultado, Intent datos) {
        super.onActivityResult(codigo, resultado, datos);
        if (codigo == PEDIR_ARCHIVOS && pendiente != null) {
            pendiente.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultado, datos));
            pendiente = null;
        }
    }

    // Al tocar atrás, la app pasa a segundo plano y la música sigue sonando.
    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }
}
